<!DOCTYPE html>
<html lang="kr">
<head>
<meta charset="utf-8">
<title>폼 입력 처리의 기본(GET)</title>
<link href="../../css/style.css" rel="stylesheet">
</head>
<body>
<div>

<form method="GET" action="checkNo.php">
  <ul>
    <li><label>번호：<input type="number" name="no"></label></li>
    <li><input type="submit" value="알아본다" /></li>
  </ul>
</form>

</div>
</body>
</html>
