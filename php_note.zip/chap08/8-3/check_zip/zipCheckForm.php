<!DOCTYPE html>
<html lang="kr">
<head>
<meta charset="utf-8">
<title>우편번호 입력</title>
<link href="../../css/style.css" rel="stylesheet">
</head>
<body>
<div>
  <form method="POST" action="zipCheck.php">
    <ul>
      <li><label>우편번호: <input type="text" name="zip"></label></li>
      <li><input type="submit" value="송신한다"></li>
    </ul>
  </form>
</div>
</body>
</html>
