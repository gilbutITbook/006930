<!DOCTYPE html>
<html lang="kr">
<head>
<meta charset="utf-8">
<title>더치페이 폼</title>
<link href="../../css/style.css" rel="stylesheet">
</head>
<body>
<div>
  <form method="POST" action="dutchtreat.php">
    <ul>
      <li><label>합계금액: <input type="number" name="sum"></label></li>
      <li><label>인원수: <input type="number" name="headcount"></label></li>
      <li><input type="submit" value="더치페이 계산"></li>
    </ul>
  </form>
</div>
</body>
</html>
