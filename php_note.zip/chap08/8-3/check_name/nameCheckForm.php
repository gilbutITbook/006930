<!DOCTYPE html>
<html lang="kr">
<head>
<meta charset="utf-8">
<title>폼 입력</title>
<link href="../../css/style.css" rel="stylesheet">
</head>
<body>
<div>
  <form method="POST" action="nameCheck.php">
    <ul>
      <li><label>이름:<input type="text" name="name"></label></li>
      <li><input type="submit" value="송신한다"></li>
    </ul>
  </form>
</div>
</body>
</html>
