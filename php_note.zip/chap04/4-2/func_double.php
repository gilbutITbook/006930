<?php
function double($n){
  $result = $n * 2;
  return $result;
}
?>

<?php
$ret = double(125);
echo $ret;
?>
