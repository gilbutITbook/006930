<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>가변 변수</title>
</head>
<body>
<?php
$color = "red";
$$color = 125;
echo $red;
 ?>
</body>
</html>
