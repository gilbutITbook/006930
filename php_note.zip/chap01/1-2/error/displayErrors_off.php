<?php
ini_set('display_errors', 0);
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>오류를 표시한다</title>
</head>
<body>
<?php
echo "행 단락을 잊었다"
echo "헬로월드";
?>
</body>
</html>
