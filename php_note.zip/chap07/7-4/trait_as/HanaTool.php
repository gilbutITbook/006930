<?php
// HanaTool 트레이트를 정의한다
trait HanaTool {
  public function hello() {
    echo "안녕히 계십시오. ";
  }
}
// ?>
