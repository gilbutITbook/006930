<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>홑따옴표 문자열에 홑따옴표를 포함한다</title>
</head>
<?php
$msg= '그곳은 Y\'s ROOM 입니다.';
echo $msg;
?>
</body>
</html>
