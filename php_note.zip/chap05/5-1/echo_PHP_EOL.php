<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>OS에 따른 개행으로 연결한다</title>
</head>
<body>
<?php
echo  "꼼주야", PHP_EOL, "사랑해";
?>
</body>
</html>
