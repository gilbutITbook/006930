<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Nowdoc</title>
</head>
<body>
<?php
$version = 7;
$msg = <<< 'EOD'
지금부터 함께 'PHP $version'을 공부합시다.
진심이에요.
EOD;
// Nowdoc를 표시한다
echo $msg;
?>
</body>
</html>
