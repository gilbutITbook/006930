<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>히어 도큐먼트</title>
</head>
<?php
$version = 7;
$msg = <<< "EOD"
지금부터는 함께 "PHP $version"을 공부합시다.
진심이에요.
EOD;
// 히어 도큐먼트를 표시한다
echo $msg;
?>
</body>
</html>
