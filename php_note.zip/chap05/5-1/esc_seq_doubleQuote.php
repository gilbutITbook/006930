<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>겹따옴표 문자열 내에 $기호를 포함한다</title>
</head>
<?php
$won = 1110;
echo "오늘 환율은 \$1 = $won 원입니다.";
?>
</body>
</html>
