<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>겹따옴표 문자열에 변수를 넣은 경우</title>
</head>
<body>
<?php
$theSize = "M";
$thePrice = 12000;
$msg = "$theSize 사이즈, $thePrice 원";
echo $msg;
?>
</body>
</html>
