<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>값을 왼쪽 정렬로 할지 오른쪽 정렬로 할지</title>
</head>
<body>
<?php
$a = "23ab";
printf("ID는 %'#-8s입니다. ", $a);
printf("ID는 %'*+8s입니다. ", $a);
?>
</body>
</html>
