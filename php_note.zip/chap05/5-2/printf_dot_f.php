<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>변수 $a,$b값을 소수 1자리로 표시한다</title>
</head>
<body>
<?php
$a = 15.69;
$b = 11.32;
printf('최댓값 %.1f, 최솟값 %.1f', $a, $b);
?>
</body>
</html>
