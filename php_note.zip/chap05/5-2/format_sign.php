<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>수치가 음일 때 -, 양일 때 +를 붙여서 표시한다</title>
</head>
<body>
<?php
$a = -5;
$b = 9;
printf('%+d', $a);
echo ", ";
printf('%+d', $b);
?>
</body>
</html>
