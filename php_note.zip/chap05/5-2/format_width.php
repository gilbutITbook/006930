<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>값의 최저 문자 수를 지정한다</title>
</head>
<body>
<?php
$a = 83;
$b = 92018;
$c = "3-A";
printf('번호는 %04d입니다. ', $a);
printf('번호는 %04d입니다. ', $b);
printf('ID는 %04s입니다. ', $c);
?>
</body>
</html>
