<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>문자열에 값을 넣는다</title>
</head>
<body>
<?php
printf('원주율은 %.2f입니다. ', M_PI);
?>
</body>
</html>
