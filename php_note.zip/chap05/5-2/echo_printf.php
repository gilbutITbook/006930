<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>소수 ３자리까지를 출력한다</title>
</head>
<body>
<?php
// 원주율을 그대로 출력한다
echo M_PI;
echo "<br>", PHP_EOL; // 개행
// 포맷 문자열을 지정해 출력한다
printf('%.3f', M_PI);
?>
</body>
</html>
