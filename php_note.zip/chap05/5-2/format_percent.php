<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>형 지정자 %의 예</title>
</head>
<body>
<?php
$per = 64.8;
printf('달성률은 %.2f%%입니다. ', $per);
?>
</body>
</html>
