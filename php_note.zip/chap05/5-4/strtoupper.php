<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>소문자를 대문자로 한다</title>
</head>
<body>
<?php
$msg = "Apple iPhone";
echo strtoupper($msg);
?>
</body>
</html>
