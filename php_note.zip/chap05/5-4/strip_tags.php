<?php
$msg = "<p><b>울릉도</b>동남쪽<br>뱃길따라<br></p>";
echo strip_tags($msg);
?>
