<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>대문자를 소문자로 한다</title>
</head>
<body>
<?php
$msg = "Apple iPhone";
echo strtolower($msg);
?>
</body>
</html>
