<!DOCTYPE html>
<html lang="kr">
<head>
  <meta charset="utf-8">
  <title>Page 2</title>
  <link href="../../css/style.css" rel="stylesheet">
</head>
<body>
<div>
  <a href="page1.php">Page 1로 돌아간다</a>
</div>
</body>
</html>
