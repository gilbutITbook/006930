<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>연관 배열을 값으로 정렬한다</title>
</head>
<body>
<pre>
<?php
$data = ["S" => 23, "M" => 36, "L" => 29];
// 오름차순으로 정렬한다
asort($data);
print_r($data);
?>
</pre>
</body>
</html>
