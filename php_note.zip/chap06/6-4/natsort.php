<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>배열을 자연순으로 정렬한다</title>
</head>
<body>
<pre>
<?php
$data = ["image7", "image12", "image1"];
// 자연순으로 정렬한다
natsort($data);
print_r($data);
?>
</pre>
</body>
</html>
