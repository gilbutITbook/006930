<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>배열을 오름차순으로 정렬한다</title>
</head>
<body>
<pre>
<?php
$data = [23, 16, 8, 42, 15, 4];
// 오름차순으로 정렬한다
sort($data);
print_r($data);
?>
</pre>
</body>
</html>
