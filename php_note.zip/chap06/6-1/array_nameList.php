<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>이름 배열</title>
</head>
<body>
<pre>
<?php
// 배열을 사용해 팀을 나눈다
$teamA = ["김철수", "이민우", "박영배"];
$teamB = ["김소라", "이수지"];

// 확인한다
print_r($nameList);
?>
</pre>
</body>
</html>
