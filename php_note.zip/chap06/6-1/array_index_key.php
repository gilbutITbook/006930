<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>인덱스 배열과 연관배열</title>
</head>
<body>
<pre>
<?php
$vlist = ["a", "b", "c"];
// 확인한다
print_r($vlist);
?>
</pre>
</body>
</html>
