<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>연관배열을 만든다</title>
</head>
<body>
<pre>
<?php
// 연관배열을 만든다
$user = [];
$user['name'] = "수지";
$user['address'] = "서울";
$user['age'] = 23;
// 확인한다
print_r($user);
?>
</pre>
</body>
</html>
