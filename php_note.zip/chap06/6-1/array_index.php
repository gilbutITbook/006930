<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>배열을 array()로 만든다</title>
</head>
<body>
<pre>
<?php
$colors = array("빨강", "파랑", "노랑");
// 확인한다
print_r($colors);
?>
</pre>
</body>
</html>
