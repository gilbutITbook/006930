<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>이름을 넣은 변수</title>
</head>
<body>
<pre>
<?php
// 변수를 사용해 회원 이름을 관리한다
$name1 = "김철수";
$name2 = "이민우";
$name3 = "박영배";
$name4 = "김소라";
$name5 = "이수지";
?>
</pre>
</body>
</html>
