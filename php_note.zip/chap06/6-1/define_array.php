<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>배열을 상수로 한다</title>
</head>
<body>
<?php
define("RANK", ["상", "중", "하"]);
echo RANK[1];
?>
</body>
</html>
