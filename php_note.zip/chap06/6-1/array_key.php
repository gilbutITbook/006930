<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>연관배열을 만든다</title>
</head>
<body>
<pre>
<?php
// 연관배열을 만든다
$goods = [
  "id" => "R56",
  "size" => "M",
  "price" => 2340
];
// 확인한다
print_r($goods);
?>
</pre>
</body>
</html>
