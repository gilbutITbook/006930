<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>배열의 연결 +연산자</title>
</head>
<body>
<pre>
<?php
$a = ["a", "b", "c"];
$b = ["d", "e", "f", "g", "h"];
// 배열을 연결한다
$result = $a + $b;
print_r($result);
?>
</pre>
</body>
</html>
