<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>대문자와 소문자의 구별</title>
</head>
<?php
$myColor = "green";
$myCOLOR = "YELLOW";
echo $myColor;
echo ",";
echo $myCOLOR;
?>
</body>
</html>
