<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>echo</title>
</head>
<body>
<?php
echo "안녕하세요, ";
ECHO "건강하시죠?";               
?>
</body>
</html>
