<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>공백과 개행</title>
</head>
<body>
<?php
$name  = "홍길동";
$age   = 17;

echo $name,", ",
     $age;
?>

</body>
</html>
