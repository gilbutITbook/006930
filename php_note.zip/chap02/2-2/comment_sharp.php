<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>주석</title>
</head>
<body>
<?php
# 이 행은 주석입니다.
echo "안녕하세요 ";
#
# 이 세 행도 주석입니다.
#
echo "감사합니다";
?>
</body>
</html>
