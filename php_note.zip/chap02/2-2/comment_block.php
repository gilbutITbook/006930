<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>주석</title>
</head>
<body>
<?php
echo "안녕하세요. ";
/*
// 이 구간은 주석입니다.
echo "감사합니다.";
*/
echo /* 중간을 주석으로*/ "안녕히 가세요.";
?>
</body>
</html>
