<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>echo</title>
</head>
<body>
<?php
echo "여러분, ";
echo "안녕하세요";
?>
</body>
</html>
