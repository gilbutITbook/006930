<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>echo</title>
</head>
<body>
<?php
echo "안녕하세요";
echo "<br>";
echo("감사합니다");
?>
</body>
</html>
