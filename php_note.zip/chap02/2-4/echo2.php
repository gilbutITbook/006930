<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>echo로 여러 값을 출력하는 예</title>
</head>
<body>
<?php
echo "안녕하세요","<br>","감사합니다";
?>
</body>
</html>
