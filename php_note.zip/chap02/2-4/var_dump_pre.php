<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>var_dump()를 브라우저에서도 쉽게 출력</title>
</head>
<body>
<pre>
<?php
$colors = array("red", "blue", "green");
var_dump($colors);
?>
</pre>
</body>
</html>
