<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>print()로 값을 출력하는 예</title>
</head>
<body>
<?php
$who = "트와이스";
$age = 19;
print $who . "님" . $age . "세";           
?>
</body>
</html>
