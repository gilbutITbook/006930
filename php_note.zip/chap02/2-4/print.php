<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>print()로 값을 출력하는 예</title>
</head>
<body>
<?php
$msg = "안녕, 빠이~";
print($msg);
?>
</body>
</html>
