<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>문자열을 대입한 변수에 수치를 대입하기</title>
</head>
<body>
<?php
$stock = "재고 없음"; // 문자열을 대입
echo $stock, "<br>";
$stock = 5; // 수치를 대입
echo $stock;
?>
</body>
</html>
