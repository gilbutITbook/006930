<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>변수로의 대입과 출력</title>
</head>
<body>
<?php
$theSize = "M";
$thePrice = 12000;
echo $theSize, "사이즈, ";
echo $thePrice, "원";
?>
</body>
</html>
