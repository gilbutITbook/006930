<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>상수</title>
</head>
<body>
<?php
define("TAX", 0.1);
$price = 1250 * (1+TAX);
echo $price;
?>
</body>
</html>
