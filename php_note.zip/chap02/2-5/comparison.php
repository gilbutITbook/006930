<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>변수 $a와 $b의 값 비교하기</title>
</head>
<body>
<pre>
<?php
$a = 7;
$b = 10;
$hantei1 = ($a<$b);
$hantei2 = ($a>$b);
var_dump($hantei1);
var_dump($hantei2);
?>
</pre>
</body>
</html>
