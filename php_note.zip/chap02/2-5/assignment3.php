<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>$a에 10을 더하기</title>
</head>
<body>
<?php
$a = 0;
$a += 10;
echo $a;
?>
</body>
</html>
