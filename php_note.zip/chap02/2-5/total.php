<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>합계를 구해 5를 뺀 최종결과를 표시</title>
</head>
<body>
<?php
$total = 80 + 40;
$result = $total - 5;
echo "합계{$total}, 최종결과{$result}";
?>
</body>
</html>
