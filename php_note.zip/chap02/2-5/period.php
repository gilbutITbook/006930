<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>문자열 연결하기</title>
</head>
<body>
<?php
$who = "내사랑";
$hello = "안녕";
$msg = $who . "님. " . $hello;
echo $msg;
?>
</body>
</html>
