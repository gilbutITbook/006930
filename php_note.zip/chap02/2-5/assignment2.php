<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>여러 변수의 값을 같은 값으로 초기화</title>
</head>
<body>
<pre>
<?php
$a = $b = $c = 100;
var_dump($a);
var_dump($b);
var_dump($c);
?>
</pre>
</body>
</html>
