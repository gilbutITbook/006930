<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>값뿐만 아니라 형도 비교하기</title>
</head>
<body>
<pre>
<?php
$result1 = ("99" === 99);
$result2 = ("99" !== 99);
var_dump($result1);
var_dump($result2);
?>
</pre>
</body>
</html>
