<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>값을 대입한 후 $a의 값을 1 증가시킴</title>
</head>
<body>
<?php
$a = 0;
$b = $a++;
echo "\$a는 {$a}, \$b는 {$b}";
?>
</body>
</html>
