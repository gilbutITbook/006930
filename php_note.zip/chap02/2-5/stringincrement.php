<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>문자열을 증가시키기</title>
</head>
<body>
<?php
$myNum = "19";
$myChar = "a";
++$myNum;
++$myChar;
echo "\$myNum은 {$myNum}、\$myChar는 {$myChar}";
?>
</body>
</html>
