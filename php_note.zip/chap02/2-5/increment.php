<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>$a에 1을 더한 후 $a의 값을 $b에 대입하기</title>
</head>
<body>
<?php
$a = 0;
$b = ++$a;
echo "\$a는 {$a}, \$b는{$b}";    
?>
</body>
</html>
