<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>$point의 값이 10 이상이면 합격</title>
</head>
<body>
<?php
$point = 11.6;
if ($point >= 10) {
  echo "합격";
} else {
  echo "실패";
}
?>
</body>
</html>
