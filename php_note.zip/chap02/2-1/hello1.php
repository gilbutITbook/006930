<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>[안녕하세요]라고 표시한다</title>
</head>
<body>
<?php
echo "안녕하세요";
?>
</body>
</html>
