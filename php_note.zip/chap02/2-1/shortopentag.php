<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>PHP 태그의 생략</title>
</head>
<? echo "안녕하세요"; ?>
</body>
</html>
