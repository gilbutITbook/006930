<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>올림픽 개최년</title>
  <link  href="./css/style.css" rel="stylesheet" type="text/css">
</head>

<?php
$year1 = "1988년";
$year2 = "2018년";
?>

<body>
<div class="main-contents">

서울 올림픽은 
<h1>
<?php echo $year1; ?>
</h1>
입니다.<br>
평창 올림픽은 
<h1>
<?php echo $year2; ?>
</h1>
입니다.<br>


</div>
</body>
</html>
