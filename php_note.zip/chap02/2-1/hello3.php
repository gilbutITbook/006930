<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>변수를 사용해 표시하기</title>
</head>
<?php
$who = "PHP 7";
echo "안녕하세요, ", $who;
?>
</body>
</html>
