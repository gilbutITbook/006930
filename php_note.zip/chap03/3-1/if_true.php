<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>85점이었을 때</title>
</head>
<body>
<?php
$score = 85;
if ($score>=80) {
  echo "우수함! ";
}
echo "{$score}점입니다."
?>
</body>
</html>
