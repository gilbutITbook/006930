<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>50점이었을 때</title>
</head>
<body>
<?php
$score = 50;
if ($score>=80) {
  echo "우수함!";
}
echo "{$score}점입니다."
?>
</body>
</html>
