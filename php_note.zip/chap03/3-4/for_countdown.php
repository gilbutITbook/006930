<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>카운터 값을 줄여간다</title>
</head>
<body>
<?php
for ($i=10; $i>0; $i--){
  echo "{$i}회. ";
}
?>
</body>
</html>
