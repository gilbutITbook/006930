<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>처리를 10회 반복</title>
</head>
<body>
<?php
for ($i=0; $i<10; $i++){
  echo "{$i}회. ";
}
?>
</body>
</html>
